Instant Script Commands 
( Touch To Copy )

apt update

apt upgrade -y

pkg install git

pkg install python

git clone https://github.com/AshenFdo2/memefi.git

cd memefi1

python main.py
